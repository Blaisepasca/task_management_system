
 ALTER TABLE projects CHANGE price price BIGINT NOT NULL;
