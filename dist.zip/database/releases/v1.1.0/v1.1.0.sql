 alter table `projects` add `status` int not null default '1'
