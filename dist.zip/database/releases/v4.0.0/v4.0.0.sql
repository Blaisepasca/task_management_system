
 ALTER TABLE projects CHANGE price price BIGINT DEFAULT NULL, CHANGE currency currency INT DEFAULT NULL, CHANGE budget_type budget_type INT DEFAULT NULL;
