@extends('layouts.app')
@section('title')
    Home
@endsection
@section('content')
  <div class="container-fluid">
        <div class="animated fadeIn">
             <div class="row">

            </div>
        </div>
    </div>
</div>
@endsection
