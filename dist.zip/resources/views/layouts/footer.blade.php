<div class="footer-left">
    {{ __('messages.common.all_rights_reserved_copyright') }} &copy; {{ date('Y') }} {{ html_entity_decode(getAppName()) }}
</div>
