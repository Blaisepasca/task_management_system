<table class="table table-responsive-sm table-striped table-bordered" id="activity_type">
    <thead>
    <tr>
        <th>{{ __('messages.activity_type.activity_type') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
