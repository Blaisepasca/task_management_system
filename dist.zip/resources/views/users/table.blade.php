<table class="table table-responsive-sm table-striped table-bordered" id="users_table">
    <thead>
    <tr>
        <th>{{ __('messages.user.name') }}</th>
        <th>{{ __('messages.user.email') }}</th>
        <th>{{ __('messages.user.phone') }}</th>
        <th>{{ __('messages.user.role') }}</th>
        <th>{{ __('messages.user.salary') }}</th>
        <th>{{ __('messages.user.active') }}</th>
        <th>{{ __('messages.user.is_email_verified') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
