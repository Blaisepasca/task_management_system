<div class="container">
    <div id="app" class="content">
        <div class="editor">
            <div class="invoice-preview-inner">
                <div class="editor-content" id="editorContent">
                </div>
            </div>
        </div>
    </div>
</div>
