<table class="table table-responsive-sm table-striped table-bordered" id="role_table">
    <thead>
    <th>{{ __('messages.role.name') }}</th>
    <th>{{ __('messages.common.details') }}</th>
    <th>{{ __('messages.common.action') }}</th>
    </thead>
    <tbody>
    </tbody>
</table>
