<table class="table table-responsive-sm table-striped table-bordered" id="expense_table">
    <thead>
    <tr>
        <th>{{__('messages.time_entry.date')}}</th>
        <th>{{ __('messages.invoice.amount')}}</th>
        <th>{{__('messages.common.created_by')}}</th>
        <th>{{__('messages.report.client')}}</th>
        <th>{{__('messages.report.project')}}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
