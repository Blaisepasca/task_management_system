<table class="table table-responsive-sm table-striped table-bordered task-detail" id="task_table">
    <thead>
    <tr>
        <th></th>
        <th>{{ __('messages.task.title') }}</th>
        <th>{{ __('messages.task.assign_to') }}</th>
        <th>{{ __('messages.task.priority') }}</th>
        <th>{{ __('messages.task.due_date') }}</th>
        <th>{{ __('messages.common.created_at') }}</th>
        <th>{{ __('messages.task.reporter') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
