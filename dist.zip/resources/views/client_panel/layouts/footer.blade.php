<div class="footer-left">
    {{ __('messages.common.all_rights_reserved_copyright') }} &copy; {{ date('Y') }} {{ getAppName() }}
</div>
