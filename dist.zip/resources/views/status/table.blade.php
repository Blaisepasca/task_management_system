<table class="table table-responsive-sm table-striped table-bordered" id="tags_table" tabindex="-1">
    <thead>
    <tr>
        <th>{{ __('messages.tag.name') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
