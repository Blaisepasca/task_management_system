<table class="table table-responsive-sm table-striped table-bordered" id="projects_table">
    <thead>
    <tr>
        <th>{{ __('messages.project.prefix') }}</th>
        <th>{{ __('messages.project.name') }}</th>
        <th>{{ __('messages.project.client') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
