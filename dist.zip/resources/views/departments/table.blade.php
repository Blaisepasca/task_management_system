<table class="table table-responsive-sm table-striped table-bordered" id="departments-table">
    <thead>
    <th>{{ __('messages.department.name') }}</th>
    <th>{{ __('messages.common.action') }}</th>
    </thead>
    <tbody></tbody>
</table>
