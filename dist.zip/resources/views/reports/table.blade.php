<table class="table table-responsive-sm table-striped table-bordered" id="report_table">
    <thead>
    <tr>
        <th>{{ __('messages.report.name') }}</th>
        <th>{{ __('messages.report.start_date') }}</th>
        <th>{{ __('messages.report.end_date') }}</th>
        <th>{{ __('messages.common.created_by') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
