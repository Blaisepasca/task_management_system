<table class="table table-responsive-sm table-striped table-bordered" id="clients_table">
    <thead>
    <tr>
        <th>{{ __('messages.client.name') }}</th>
        <th>{{ __('messages.client.department') }}</th>
        <th>{{ __('messages.client.email') }}</th>
        <th>{{ __('messages.client.website') }}</th>
        <th>{{ __('messages.common.action') }}</th>
    </tr>
    </thead>
    <tbody></tbody>
</table>
